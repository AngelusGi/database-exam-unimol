var searchData=
[
  ['queryfullcustom',['QueryFullCustom',['../class_progetto_basi_dati_1_1_query_sql.html#af08faee274bda19ad18d455840285484',1,'ProgettoBasiDati::QuerySql']]],
  ['querymenu',['QueryMenu',['../class_progetto_basi_dati_1_1_query_sql.html#a62505045a3e1533982840966622dfd16',1,'ProgettoBasiDati::QuerySql']]]
];
