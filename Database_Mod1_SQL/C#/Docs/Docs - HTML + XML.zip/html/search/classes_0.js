var searchData=
[
  ['connection',['Connection',['../class_progetto_basi_dati_1_1_connection.html',1,'ProgettoBasiDati']]]
];
