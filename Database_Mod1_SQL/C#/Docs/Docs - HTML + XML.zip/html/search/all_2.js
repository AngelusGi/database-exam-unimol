var searchData=
[
  ['progettobasidati',['ProgettoBasiDati',['../namespace_progetto_basi_dati.html',1,'']]]
];
