var searchData=
[
  ['querysql',['QuerySql',['../class_progetto_basi_dati_1_1_query_sql.html',1,'ProgettoBasiDati']]]
];
