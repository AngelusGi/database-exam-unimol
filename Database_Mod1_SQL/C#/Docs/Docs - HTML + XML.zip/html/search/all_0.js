var searchData=
[
  ['callquery',['CallQuery',['../class_progetto_basi_dati_1_1_query_sql.html#a0966c03ac72700827c41b76d5f063a7d',1,'ProgettoBasiDati.QuerySql.CallQuery(int selection)'],['../class_progetto_basi_dati_1_1_query_sql.html#abdd29ff7aff256b67c7fbc47e2ef5f0c',1,'ProgettoBasiDati.QuerySql.CallQuery(string gender, string size, double price)'],['../class_progetto_basi_dati_1_1_query_sql.html#a6d0a34f2360239a0003d2aec8b7bc9db',1,'ProgettoBasiDati.QuerySql.CallQuery(string gender)']]],
  ['connection',['Connection',['../class_progetto_basi_dati_1_1_connection.html',1,'ProgettoBasiDati']]],
  ['connectionmenu',['ConnectionMenu',['../class_progetto_basi_dati_1_1_connection.html#a987e6341acd2b40523ad1e351d1c7e85',1,'ProgettoBasiDati::Connection']]]
];
