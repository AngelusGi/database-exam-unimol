var class_progetto_basi_dati_1_1_query_sql =
[
    [ "CallQuery", "class_progetto_basi_dati_1_1_query_sql.html#a0966c03ac72700827c41b76d5f063a7d", null ],
    [ "CallQuery", "class_progetto_basi_dati_1_1_query_sql.html#abdd29ff7aff256b67c7fbc47e2ef5f0c", null ],
    [ "CallQuery", "class_progetto_basi_dati_1_1_query_sql.html#a6d0a34f2360239a0003d2aec8b7bc9db", null ],
    [ "QueryFullCustom", "class_progetto_basi_dati_1_1_query_sql.html#af08faee274bda19ad18d455840285484", null ],
    [ "QueryMenu", "class_progetto_basi_dati_1_1_query_sql.html#a62505045a3e1533982840966622dfd16", null ]
];