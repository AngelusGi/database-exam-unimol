var class_progetto_basi_dati_1_1_gui =
[
    [ "Menu", "class_progetto_basi_dati_1_1_gui.html#a48ae40cbb1cd729ea196cd90d11bfa99", null ]
];