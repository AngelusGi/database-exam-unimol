var searchData=
[
  ['start',['Start',['../class_progetto_basi_dati_1_1_start.html',1,'ProgettoBasiDati']]]
];
